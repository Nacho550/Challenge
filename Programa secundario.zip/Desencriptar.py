from asyncio import CancelledError
import sqlite3
import decrypt
import time


print("Iniciando desencripción...")
      
time.sleep(3)


# Conexion a la db
conn = sqlite3.connect("DataEntry.db")
crsr = conn.cursor()

# Intenta generar una nueva tabla dentro de DB, si esta creada el programa continua
try:
    crsr.execute ("""CREATE TABLE Datos_Desencriptados(credit_card_num,credit_card_ccv,cuenta_numero)""")
    print("Se esta generando la tabla 'Datos_Desencriptados'")
except:
    print("Actualizando la informacion...")
    
time.sleep(3)

#Vuelca los datos a la nueva tabla para los datos desencriptados
sql_command = """INSERT INTO Datos_Desencriptados(credit_card_num,credit_card_ccv,cuenta_numero)
    VALUES (?,?,?);"""


crsr.execute("SELECT credit_card_num FROM Informacion_Rescatada")
rows = crsr.fetchall()
for row in rows:
    for col1 in row:
        credit_card_num = decrypt.Decrypt(col1)

crsr.execute("SELECT credit_card_ccv FROM Informacion_Rescatada")
rows = crsr.fetchall()
for row in rows:
    for col2 in row:
        credit_card_ccv = (decrypt.Decrypt(col2))
        
crsr.execute("SELECT cuenta_numero FROM Informacion_Rescatada")
rows = crsr.fetchall()
for row in rows:
    for col3 in row:
        cuenta_numero = (decrypt.Decrypt(col3))

tup = (credit_card_num, credit_card_ccv, cuenta_numero)
crsr.execute(sql_command,tup)


conn.commit()
conn.close()

print("La informacion desencriptada se encuentra en la base 'DataEntry.db'.\ndentro de este recurso, en la tabla 'Datos_Desencriptados")
time.sleep(5)

input("Presione 'enter' para finalizar...")