import sqlite3
import encrypt
import pandas
from cryptography.fernet import Fernet
import time

# Genera la llave para la posterior encripcion del archivo.
key = Fernet.generate_key()
with open("universal.key","wb") as key_files:
      key_files.write(key)
      
print("Iniciando programa...")
      
time.sleep(3)

#Extrae los datos de la web y los deja en formato dataframe.
url = "https://62433a7fd126926d0c5d296b.mockapi.io/api/v1/usuarios"
data = pandas.read_json(url)

# Conexion a la db
conn = sqlite3.connect("DataEntry.db")
crsr = conn.cursor()

# Intenta generar una tabla dentro de DB, si esta creada el programa continua
try:
    crsr.execute ("""CREATE TABLE Informacion_Rescatada(fec_alta,user_name,codigo_zip,credit_card_num,credit_card_ccv, cuenta_numero, direccion, geo_latitud, geo_longitud, color_favorito, foto_dni, ip, auto, auto_modelo, auto_tipo, auto_color, cantidad_compras_realizadas, avatar, fec_birthday, id)""")
    print("Se esta generando la informacion solicitada...")
except:
    print("Actualizando la informacion...")
    
time.sleep(3)

# Inserta los datos extraidos en la tabla generada con anterioridad
sql_command = """INSERT INTO Informacion_Rescatada(fec_alta, user_name, codigo_zip, credit_card_num, credit_card_ccv, cuenta_numero, direccion, geo_latitud, geo_longitud, color_favorito, foto_dni, ip, auto, auto_modelo, auto_tipo, auto_color, cantidad_compras_realizadas, avatar, fec_birthday, id)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"""
    
#Trae del dataframe solo la informacion de cada columna
fecalta = data['fec_alta']
user_name = data['user_name']
codigo_zip = data['codigo_zip']
credit_card_num = data['credit_card_num']
credit_card_ccv = data['credit_card_ccv']
cuenta_numero = data['cuenta_numero']
direccion = data['direccion']
geo_latitud = data['geo_latitud']
geo_longitud = data['geo_longitud']
color_favorito = data['color_favorito']
foto_dni = data['foto_dni']
ip = data['ip']
auto = data['auto']
auto_modelo = data['auto_modelo']
auto_tipo = data['auto_tipo']
auto_color = data['auto_color']
cantidad_compras_realizadas = data['cantidad_compras_realizadas']
avatar = data['avatar']
fec_birthday = data['fec_birthday']
id = data['id']


#Convertir las columnas en Strings
fecalta = fecalta.to_string(index=False)
user_name = user_name.to_string(index=False)
codigo_zip = codigo_zip.to_string(index=False)
credit_card_num = credit_card_num.to_string(index=False)
credit_card_ccv = credit_card_ccv.to_string(index=False)
cuenta_numero = cuenta_numero.to_string(index=False)
direccion = direccion.to_string(index=False)
geo_latitud = geo_latitud.to_string(index=False)
geo_longitud = geo_longitud.to_string(index=False)
color_favorito = color_favorito.to_string(index=False)
foto_dni = foto_dni.to_string(index=False)
ip = ip.to_string(index=False)
auto = auto.to_string(index=False)
auto_modelo = auto_modelo.to_string(index=False)
auto_tipo = auto_tipo.to_string(index=False)
auto_color = auto_color.to_string(index=False)
cantidad_compras_realizadas = cantidad_compras_realizadas.to_string(index=False)
avatar = avatar.to_string(index=False)
fec_birthday = fec_birthday.to_string(index=False)
id = id.to_string(index=False)


################# Este paso encripta los datos sensibles (Datos de cuenta y tarjeta), Todos los demas #####
################# datos se encuentran comentados, con la posibilidad de encriptarlos tambien ##############

#fecalta = encrypt.Encrypt(fecalta)
#user_name = encrypt.Encrypt(user_name)
#codigo_zip = encrypt.Encrypt(codigo_zip)
credit_card_num = encrypt.Encrypt(credit_card_num)
credit_card_ccv = encrypt.Encrypt(credit_card_ccv)
cuenta_numero = encrypt.Encrypt(cuenta_numero)
#direccion = encrypt.Encrypt(direccion)
#geo_latitud = encrypt.Encrypt(geo_latitud)
#geo_longitud = encrypt.Encrypt(geo_longitud)
#color_favorito = encrypt.Encrypt(color_favorito)
#foto_dni = encrypt.Encrypt(foto_dni)
#ip = encrypt.Encrypt(ip)
#auto = encrypt.Encrypt(auto)
#auto_modelo = encrypt.Encrypt(auto_modelo)
#auto_tipo = encrypt.Encrypt(auto_tipo)
#auto_color = encrypt.Encrypt(auto_color)
#cantidad_compras_realizadas = encrypt.Encrypt(cantidad_compras_realizadas)
#avatar = encrypt.Encrypt(avatar)
#fec_birthday = encrypt.Encrypt(fec_birthday)
#id = encrypt.Encrypt(id)

tup = (fecalta,user_name,codigo_zip,credit_card_num,credit_card_ccv, cuenta_numero, direccion, geo_latitud, geo_longitud, color_favorito, foto_dni, ip, auto, auto_modelo, auto_tipo, auto_color, cantidad_compras_realizadas, avatar, fec_birthday, id)

#Ejecuta las acciones solictadas anteriormente en la DB
crsr.execute(sql_command,tup)
conn.commit()
conn.close() 

print("Se actualizo tu informacion en la base 'DataEntry.db' dentro de este recurso")
time.sleep(5)

input("Presione 'enter' para finalizar...")